<?php

/**
 * @Project NUKEVIET 4.x
 * @This product includes GeoLite2 data created by MaxMind, available from http://www.maxmind.com
 * @Createdate Wed, 18 Apr 2018 03:19:55 GMT
 */

$ranges=array(184549376=>array(185405200,'US'),185405201=>array(185405201,'CZ'),185405202=>array(185999659,'US'),185999660=>array(185999660,'FR'),185999661=>array(201326591,'US'));
